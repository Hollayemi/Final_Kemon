<?php 
    $body = "true";
    include('pages_header.php');
    include('pageFrame.php');
    include('pages_footer.php') 
 ?>
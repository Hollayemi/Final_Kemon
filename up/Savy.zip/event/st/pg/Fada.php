<?php  
            $name = 'Fada';
            include('../st/sc.php'); 
            // include('../st/pages_footer.php'); 
            ?>
              
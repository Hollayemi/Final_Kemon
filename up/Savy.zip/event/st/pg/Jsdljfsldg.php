<?php  
            $name = 'Jsdljfsldg';
            include('../st/sc.php'); 
            // include('../st/pages_footer.php'); 
            ?>
              
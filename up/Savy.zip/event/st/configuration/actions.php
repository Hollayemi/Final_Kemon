<?php
    require_once('config.php');
    

    // print_r($sellerInfo);
?>
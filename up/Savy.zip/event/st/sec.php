  <div  class="rating_star" style="padding:5px">
    <i class="fa fa-star fa-2x" style="color:#ccc" data-index=0></i> 
    <i class="fa fa-star fa-2x" style="color:#ccc" data-index=1></i>
    <i class="fa fa-star fa-2x" style="color:#ccc" data-index=2></i>
    <i class="fa fa-star fa-2x" style="color:#ccc" data-index=3></i>
    <i class="fa fa-star fa-2x" style="color:#ccc" data-index=4></i>
  </div>
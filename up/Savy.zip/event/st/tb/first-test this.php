<?php  
            $sc = 'uiii';
            $name = 'test this';
            $namePage = 'first';
            $tab = 'true';
            include('../st/pagebody.php');  
            ?>
<?php  
            $sc = 'uiii';
            $name = 'no_one';
            $namePage = 'first';
            $tab = 'true';
            include('../st/pagebody.php');  
            ?>
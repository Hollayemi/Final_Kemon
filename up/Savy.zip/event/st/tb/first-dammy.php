<?php  
            $sc = 'uiii';
            $name = 'dammy';
            $namePage = 'first';
            $tab = 'true';
            include('../st/pagebody.php');  
            ?>
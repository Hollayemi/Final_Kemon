<?php  
    $sc =   "kjf";       
    require_once('../webTemp.php');     
    $name = 'Automobile';
    include('../../'.$webTemp.'/st/sc.php'); 
?>
              
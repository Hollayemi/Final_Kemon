<?php  
            $name = 'Xiomi';
            include('../st/sc.php'); 
            // include('../st/pages_footer.php'); 
            ?>
              
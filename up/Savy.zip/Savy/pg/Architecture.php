<?php  
    $sc =   "kjf";
    require_once('../webTemp.php');
    $name = 'Architecture';
    include('../../'.$webTemp.'/st/sc.php'); 
?>
              
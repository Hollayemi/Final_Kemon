<?php 
    require_once('webTemp.php');
    include('../'.$webTemp.'/st/Home.php')?>
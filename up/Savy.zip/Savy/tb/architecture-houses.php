<?php  
              $sc = 'uiii';
              require_once('../webTemp.php');
              $name = 'houses';
              $namePage = 'architecture';
              $tab = 'true';
              include('../../'.$webTemp.'/st/pagebody.php');    
        ?>
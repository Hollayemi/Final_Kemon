<?php  
      $sc = 'uiii';
      require_once('../webTemp.php');
      $name = 'bridges';
      $namePage = 'architecture';
      $tab = 'true';
    include('../../'.$webTemp.'/st/pagebody.php');  
?>
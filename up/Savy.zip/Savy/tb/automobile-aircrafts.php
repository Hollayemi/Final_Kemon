<?php  
              $sc = 'uiii';
              require_once('../webTemp.php');
              $name = 'aircrafts';
              $namePage = 'automobile';
              $tab = 'true';
              include('../../'.$webTemp.'/st/pagebody.php');    
        ?>
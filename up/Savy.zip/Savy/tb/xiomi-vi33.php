<?php  
              $sc = 'uiii';
              $name = 'vi33';
              $namePage = 'xiomi';
              $tab = 'true';
            include('../st/pagebody.php');  
        ?>
<?php  
              $sc = 'uiii';
              require_once('../webTemp.php');
              $name = 'cars';
              $namePage = 'automobile';
              $tab = 'true';
              include('../../'.$webTemp.'/st/pagebody.php');  
        ?>